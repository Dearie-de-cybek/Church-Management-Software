

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center"><strong>All Sermons</strong></h1>
    <table id="myTable" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th scope="col">Date Created</th>
                <th scope="col">Name</th>
                <th scope="col">Author</th>
                <th scope="col">Duration</th>
                <th scope="col">Date</th>
                <th scope="col">Audio</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $sermons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sermon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background: none">
                    <td> <?php echo e($sermon->created_at); ?> </td>
                    <td> <?php echo e($sermon->name); ?> </td>
                    <td> <?php echo e($sermon->author); ?> </td>
                    <td> <?php echo e($sermon->duration); ?> mins </td>
                    <td> <?php echo e($sermon->date); ?> </td>
                    <td>
                        <audio controls>
                            <source src="<?php echo e(asset('storage/'.$sermon->audio)); ?>" type="audio/mpeg">
                            Your browser does not support the audio element.
                        </audio>
                    </td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
    $('#myTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/sermon_and_prayer/sermon/index.blade.php ENDPATH**/ ?>