<?php if($user->is_admin == 1): ?>
    

    <?php $__env->startSection('content'); ?>
        <div class="container">
            
            <table id="myTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Time Payed</th>
                        <th scope="col">Name</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Payment Type</th>
                        <th scope="col">Status</th>
                        <th scope="col">Validate</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $id= $payment->id
                    ?>
                        <tr style="background: none">
                            <td> <?php echo e($payment->created_at); ?> </td>
                            <td> <?php echo e($payment->name); ?> </td>
                            <td> <?php echo e($payment->amount); ?> </td>
                            <td> <?php echo e($payment->payment); ?> </td>
                            <td>
                                <?php if($payment->status == "Approved"): ?>
                                    <button class="btn btn-sm btn-success"> <?php echo e($payment->status); ?> </button>

                                <?php elseif($payment->status == "Decline"): ?>
                                    <button class="btn btn-sm btn-danger"> <?php echo e($payment->status); ?> </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-primary"> <?php echo e($payment->status); ?> </button>
                                <?php endif; ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('dashboard.approve', $payment->id)); ?>" class="btn btn-sm btn-outline-success m-1" >Approve</a>
                                <a href="<?php echo e(route('dashboard.decline', $payment->id)); ?>" class="btn btn-sm btn-outline-danger m-1" >Decline</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
            <h1 class="text-center"><strong >Payment Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('user.pay')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Name: </label>
                    <input type="text" name="name" id="name" class="form-control" required>

                    <label for="amount" class="form-label">Amount: </label>
                    <input type="text" name="amount" id="amount" class="form-control" required>

                    <label for="payment_type" class="form-label">Payment Type: </label>
                    
                    <select class="form-select mb-3" aria-label=".form-select-lg example" name="payment_type" required>
                        <option selected>Select Your Payment Type</option>
                        <option value="Offering">Offering</option>
                        <option value="Prophetic Seed">Prophetic Seed</option>
                        <option value="Tithe">Tithe</option>
                        <option value="Church Project">Church Project</option>
                    </select>


                    <input type="text" name="status" id="Status" value="Pending" class="form-control" hidden>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        

        
            <h1 class="text-center"><strong >News</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('dashboard.news.news')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="title" class="form-label">Title: </label>
                    <input type="text" name="title" id="title" class="form-control" required>

                    <label for="description" class="form-label">Description: </label>
                    <textarea type="text" name="description" id="description" class="form-control" required></textarea>

                    <label for="slug" class="form-label">Slug: </label>
                    <input type="text" name="slug" id="slug" class="form-control" required>

                    <label for="image" class="form-label">Image: </label>
                    <input type="file" name="image" id="image" value="Pending" class="form-control">

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        

        
            
        

        
            <h1 class="text-center"><strong >Sermon Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('dashboard.sermon.sermons')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Name: </label>
                    <input type="text" name="name" id="name" class="form-control" required>

                    <label for="author" class="form-label">Author: </label>
                    <input type="text" name="author" id="author" class="form-control" required>

                    <label for="duration" class="form-label">Duration: </label>
                    <input type="number" name="duration" id="duration" class="form-control" required>

                    <label for="data" class="form-label">Date: </label>
                    <input type="date" name="date" id="data" value="Pending" class="form-control" required>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        

        
            <h1 class="text-center"><strong >Event Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('dashboard.event.events')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Name: </label>
                    <input type="text" name="name" id="name" class="form-control" required>

                    <label for="author" class="form-label">Author: </label>
                    <input type="text" name="author" id="author" class="form-control" required>

                    <label for="event_category_id" class="form-label">Category: </label>
                    <select name="event_category_id" id="event_category_id" class="form-select">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    

                    <label for="data" class="form-label">Date: </label>
                    <input type="date" name="date" id="data" value="Pending" class="form-control" required>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        

        
            
        

        
            <h1 class="text-center"><strong >Appointment Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('user.appointments')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Name: </label>
                    <input type="text" name="name" id="name" class="form-control" required>

                    <label for="email" class="form-label">Email: </label>
                    <input type="text" name="email" id="email" class="form-control" required>

                    <label for="phone" class="form-label">Phone Number: </label>
                    <input type="text" name="phone" id="phone" class="form-control" required>

                    <label for="message" class="form-label">Message:</label>
                    <textarea name="message" id="message" class="form-control" cols="30" rows="10"></textarea>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        


        <script>
            $(document).ready(function() {
            $('#myTable').DataTable();
            });
        </script>

        
            <h1 class="text-center"><strong >Register Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="name" class="form-label">Name: </label>
                    <input type="text" name="name" id="name" class="form-control" required>

                    <label for="surname" class="form-label">Surname: </label>
                    <input type="text" name="surname" id="surname" class="form-control" required>

                    <label for="username" class="form-label">Username: </label>
                    <input type="text" name="username" id="username" class="form-control" required>

                    <label for="phone_number" class="form-label">Phone Number: </label>
                    <input type="text" name="phone_number" id="phone_number" class="form-control" required>

                    <label for="email" class="form-label">Email: </label>
                    <input type="text" name="email" id="email" class="form-control" required>

                    <label for="password" class="form-label">Password: </label>
                    <input type="password" name="password" id="password" class="form-control" required>

                    <label for="password_confirmation" class="form-label">Password: </label>
                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>

                    <label for="martial_status" class="form-label">Martial Status: </label>
                    <input type="text" name="martial_status" id="martial_status" class="form-control" required>

                    <label for="nationality" class="form-label">Nationality: </label>
                    <input type="text" name="nationality" id="nationality" class="form-control" required>

                    <label for="gender" class="form-label">Gender: </label>
                    <input type="text" name="gender" id="gender" class="form-control" required>

                    <label for="dob" class="form-label">Date Of Birth: </label>
                    <input type="date" name="dob" id="dob" class="form-control" required>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        

        
            <h1 class="text-center"><strong >Login Form</strong></h1>
            <div class="container">
                <form method="POST" action="<?php echo e(route('login')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="email" class="form-label">Email: </label>
                    <input type="text" name="email" id="email" class="form-control" required>

                    <label for="password" class="form-label">Password: </label>
                    <input type="password" name="password" id="password" class="form-control" required>

                    <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
                </form>
            </div>
        



    <?php $__env->stopSection(); ?>
<?php else: ?>
    <h1>Login With App</h1>
<?php endif; ?>







<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/index.blade.php ENDPATH**/ ?>