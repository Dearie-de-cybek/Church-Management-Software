<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                <div class="card-body">
                <p class="card-text"><strong>Church Project</strong></p>
                <h3 class="card-text">&#x20A6;<?php echo e($churchProjects); ?></h3>
                </div>
            </div>
        </div>
    <div>

    <div class="container mt-5">
        <h1 class="text-center"><strong>Church Project Payments</strong></h1>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Time Payed</th>
                    <th scope="col">Name</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Payment Type</th>
                    <th scope="col">Status</th>
                    <th scope="col">Validate</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id= $payment->id
                ?>
                    <?php if($payment->payment == "Church Project"): ?>


                    <tr style="background: none">
                        <td> <?php echo e($payment->created_at); ?> </td>
                        <td> <?php echo e($payment->name); ?> </td>
                        <td> <?php echo e($payment->amount); ?> </td>
                        <td> <?php echo e($payment->payment); ?> </td>
                        <td>
                            <?php if($payment->status == "Approved"): ?>
                                <button class="btn btn-sm btn-success"> <?php echo e($payment->status); ?> </button>

                            <?php elseif($payment->status == "Decline"): ?>
                                <button class="btn btn-sm btn-danger"> <?php echo e($payment->status); ?> </button>
                            <?php else: ?>
                                <button class="btn btn-sm btn-primary"> <?php echo e($payment->status); ?> </button>
                            <?php endif; ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.approve', $payment->id)); ?>" class="btn btn-sm btn-outline-success m-1" onclick="geek()">Approve</a>
                            <a href="<?php echo e(route('dashboard.decline', $payment->id)); ?>" class="btn btn-sm btn-outline-danger m-1" onclick="geek()">Decline</a>

                            <script>
                                function geek() {
                                    confirm(`All you sure you want to Finalize the Payment Note: This change cannot be reversed`);
                                }
                            </script>
                        </td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/payment/churchProject.blade.php ENDPATH**/ ?>