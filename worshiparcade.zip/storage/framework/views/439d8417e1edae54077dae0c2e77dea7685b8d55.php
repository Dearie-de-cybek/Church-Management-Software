<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                    <p class="card-text"><strong>Offering</strong></p>
                    <h3 class="card-text">&#x20A6;<?php echo e($offerings); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                    <p class="card-text"><strong>Tithe</strong></p>
                    <h3 class="card-text">&#x20A6;<?php echo e($tithes); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                    <p class="card-text"><strong>Church Project</strong></p>
                    <h3 class="card-text">&#x20A6;<?php echo e($churchProjects); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                    <p class="card-text"><strong>Prophetic Seeds</strong></p>
                    <h3 class="card-text">&#x20A6;<?php echo e($propheticSeeds); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                    <p class="card-text"><strong>Totals Revenue</strong></p>
                    <h3 class="card-text">&#x20A6;<?php echo e($propheticSeeds + $churchProjects + $offerings + $tithes); ?></h3>
                    </div>
                </div>
            </div>
        <div>
    </div>

    <div class="container">
        <h1 class="text-center mt-5"><strong>All Payment Record</strong></h1>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Time Payed</th>
                    <th scope="col">Name</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Payment Type</th>
                    <th scope="col">Status</th>
                    <th scope="col">Validate</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id= $payment->id
                ?>
                    <tr style="background: none">
                        <td> <?php echo e($payment->created_at); ?> </td>
                        <td> <?php echo e($payment->name); ?> </td>
                        <td> <?php echo e($payment->amount); ?> </td>
                        <td> <?php echo e($payment->payment); ?> </td>
                        <td>
                            <?php if($payment->status == "Approved"): ?>
                                <button class="btn btn-sm btn-success"> <?php echo e($payment->status); ?> </button>

                            <?php elseif($payment->status == "Decline"): ?>
                                <button class="btn btn-sm btn-danger"> <?php echo e($payment->status); ?> </button>
                            <?php else: ?>
                                <button class="btn btn-sm btn-primary"> <?php echo e($payment->status); ?> </button>
                            <?php endif; ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.approve', $payment->id)); ?>" class="btn btn-sm btn-outline-success m-1" >Approve</a>
                            <a href="<?php echo e(route('dashboard.decline', $payment->id)); ?>" class="btn btn-sm btn-outline-danger m-1" >Decline</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <canvas id="pieChart" style="max-height: 400px;"></canvas>
    <script>
    document.addEventListener("DOMContentLoaded", () => {
        new Chart(document.querySelector('#pieChart'), {
        type: 'pie',
        data: {
            labels: [
            'Tithe',
            'Offering',
            'Church Project',
            'Prophetic Seed'
            ],
            datasets: [{
            label: 'My First Dataset',
            data: [
                <?php
                    $totals = [$tithes, $offerings, $churchProjects, $propheticSeeds];


                    foreach ($totals as $total) {
                        echo $total . ",";
                    }
                ?>

            ],
            backgroundColor: [
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)',
                'rgb(0,255,255)'
            ],
            hoverOffset: 4
            }]
        }
        });
    });
    </script>

    
















    <script>
        $(document).ready(function() {
        $('#myTable').DataTable();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/payment/index.blade.php ENDPATH**/ ?>