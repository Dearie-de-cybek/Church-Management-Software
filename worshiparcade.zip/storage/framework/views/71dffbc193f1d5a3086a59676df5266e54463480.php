<?php $__env->startSection('content'); ?>
    <div class="container">
        <div>
            <a href="<?php echo e(route('dashboard.news.add-news')); ?>"><button class="btn btn-outline-info btn-sm"><i class="bi bi-plus"></i> Add News</button></a>
        </div>
        <h1 class="text-center"><strong>All News</strong></h1>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Time Payed</th>
                    <th scope="col">Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Slug</th>
                    <th scope="col">Image</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background: none">
                        <td> <?php echo e($new->created_at); ?> </td>
                        <td> <?php echo e($new->title); ?> </td>
                        <td> <?php echo e($new->description); ?> </td>
                        <td> <?php echo e($new->slug); ?> </td>
                        <td> <img src="<?php echo e(asset('storage/'.$new->image)); ?>" class="img-fluid" alt=""> </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.news.edit-news', $new->id)); ?>"><button class="btn btn-sm btn-outline-info"><i class="bi bi-pencil-square"></i>Edit</button></a>
                            <a href="<?php echo e(route('dashboard.news.delete-news', $new->id)); ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i>Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
        $('#myTable').DataTable();
        });
    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/news_and_event/news/index.blade.php ENDPATH**/ ?>