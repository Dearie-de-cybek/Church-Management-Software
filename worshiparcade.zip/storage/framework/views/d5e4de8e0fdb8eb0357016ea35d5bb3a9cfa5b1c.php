

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/sermon_and_prayer/sermon/sermon.blade.php ENDPATH**/ ?>