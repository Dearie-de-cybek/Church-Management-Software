<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>All Events</strong></h1>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Opening Prayer</th>
                    <th scope="col">Topic</th>
                    <th scope="col">Bible Text</th>
                    <th scope="col">Memory Verse</th>
                    <th scope="col">Devotion</th>
                    <th scope="col">Closing Prayer</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $devotionals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devotional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background: none">
                        <td> <?php echo e($devotional->created_at); ?> </td>
                        <td> <?php echo e($devotional->opening_prayer); ?> </td>
                        <td> <?php echo e($devotional->topic); ?> </td>
                        <td> <?php echo e($devotional->bible_text); ?> </td>
                        <td> <?php echo e($devotional->memory_verse); ?> </td>
                        <td> <?php echo e($devotional->devotion); ?> </td>
                        <td> <?php echo e($devotional->closing_prayer); ?> </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.devotion.edit-devotion', $devotional->id)); ?>"><button class="btn btn-sm btn-outline-info"><i class="bi bi-pencil-square"></i>Edit</button></a>
                            <a href="<?php echo e(route('dashboard.devotion.delete-devotion', $devotional->id)); ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i>Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
        $('#myTable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/devotional/index.blade.php ENDPATH**/ ?>