

<?php $__env->startSection('content'); ?>
<div class="container">
    <form method="POST" action="<?php echo e(route('dashboard.event-category.update-event-category', $eventCategory->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="name" class="form-label">Name: </label>
        <input type="text" name="name" id="name" class="form-control" required>

        <label for="slug" class="form-label">Slug: </label>
        <input type="text" name="slug" id="slug" class="form-control" required>

        <button class="btn btn-sm btn-outline-info mt-3" type="submit">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Michael\Desktop\Websites\Church-Management-Software\resources\views/dashboard/news_and_event/event_categories/edit.blade.php ENDPATH**/ ?>